const Hapi = require('@hapi/hapi');
const Vision = require('@hapi/vision')
const hbs = require('hbs');
const fetch = require("node-fetch");
const server = new Hapi.Server({host: 'localhost', port: 3020});

server.route({
  method: 'GET',
  path: '/git',
  handler:async (request, h) => {
       let search = request.query.search ? request.query.search : 'nodejs';
       let offset = request.query.offset;
       let numResults = request.query.numResults;
       let page = (offset -1) * numResults
       let perPage = offset * numResults
       console.log(page);
       console.log(perPage);
       return fetch(`https://api.github.com/search/repositories?q=${search}${page ? `&page=${page}`: ''}${perPage ? `&per_page=${perPage}`:''}`)
          .then(response => response.json())
          .then(data => {
              console.log(data)
              console.log(data.items);
              for (let i = 0 ; i < data.items.length ; i ++){
                return h.view('index', {result : data.items })
              }
          })
          .catch(err => console.log(err));
  }
});


server.route({
  method: 'POST',
  path: '/listToTree',
  handler:async (request, h) => {
        let body = request.payload ? request.payload: '';
        let result =[];
        for (let key in body){
            if(body[key].length){
                let arr = body[key]
                for(let i = 0 ; i< arr.length; i++){
                    result.push(arr[i]);
                }
            }
        } 
        let treeList = await listToTree(result);
        console.log(treeList);
        result = JSON.stringify(treeList);
        return h.response (result);
  }
});

let listToTree = async (array) => {
  let result = [];
  let map = {}, node, i;
      for (i = 0; i < array.length; i += 1) {
         map[array[i].id] = i;
         array[i].children = [];
      };
      for (i = 0; i < array.length; i += 1) {
         node = array[i];
         if (node.parent_id !== null) {
          array[map[node.parent_id]].children.push(node);
         }
         else {
          result.push(node);
         };
      };
      return result;
  }

async function start () {
    try {
      await server.start();
      await server.register(Vision);
      await server.views({engines: {html: hbs}, relativeTo: __dirname, path: 'templates'});
    }
    catch (err) {
      console.log(err);
      process.exit(1);
    }
  
    console.log('Server running at:', server.info.uri);
  };
start();
